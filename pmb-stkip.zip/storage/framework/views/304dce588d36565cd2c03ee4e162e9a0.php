<?php $__env->startSection('container'); ?>

<div class="wrapper d-flex align-items-stretch">
  <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="content" class="p-md-3">
    <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

<table class="table mx-4">
    <tr><td>nama</td>
        <td><?php echo e($register->nama); ?></td>
    </tr>
    <tr><td>jenis kelamin</td>
        <td><?php echo e($register->jk); ?></td>
    </tr>
    <tr><td>hp</td>
        <td><?php echo e($register->hp); ?></td>
    </tr>
    <tr><td>email</td>
        <td><?php echo e($register->email); ?></td>
    </tr>
    <tr><td>tempat, tanggal lahir</td>
        <td><?php echo e($register->tempat_lahir); ?>, <?php echo e(\Carbon\Carbon::parse($register->tanggal_lahir)->format('d-m-Y')); ?></td>
    </tr>
    <tr><td>alamat</td>
        <td><?php echo e($register->alamat); ?></td>
    </tr>
    <tr><td>kewarganegaraan</td>
        <td><?php echo e($register->kewarganegaraan); ?></td>
    </tr>
    <tr><td>identitas kewarganegaraan</td>
        <td><?php echo e($register->identitas_kewarganegaraan); ?></td>
    </tr>
    <tr><td>nama ibu</td>
        <td><?php echo e($register->nama_ibu); ?></td>
    </tr>
    <tr><td>nama sekolah asal</td>
        <td><?php echo e($register->nama_sekolah); ?></td>
    </tr>
    <tr><td>jenis sekolah</td>
        <td><?php echo e($register->jenis_sekolah); ?></td>
    </tr>
    <tr><td>jurusan sekolah</td>
        <td><?php echo e($register->jurusan_sekolah); ?></td>
    </tr>
    <tr><td>tahun lulus</td>
        <td><?php echo e($register->tahun_lulus); ?></td>
    </tr>
    <tr><td>NISN</td>
        <td><?php echo e($register->nisn); ?></td>
    </tr>
    <tr><td>alamat sekolah</td>
        <td><?php echo e($register->alamat_sekolah); ?></td>
    </tr>
    <tr>
        <td>Jenjang Pendidikan</td>
        <td>
            <?php
                $jenjangPendidikan = DB::table('jenjang_pendidikans')->where('id', $register->jenjang_pendidikan_id)->first();
            ?>
            <?php echo e($jenjangPendidikan->nama); ?>

        </td>
    </tr>
    <tr><td>sistem kuliah</td>
        <td>
            <?php
                $sistemKuliah = DB::table('sistem_kuliahs')->where('id', $register->sistem_kuliah_id)->first();
            ?>
            <?php echo e($sistemKuliah->nama); ?>

        </td>
    </tr>
    <tr><td>jalur masuk</td>
        <td>
            <?php
                $jalurMasuk = DB::table('jalur_masuks')->where('id', $register->jalur_masuk_id)->first();
            ?>
            <?php echo e($jalurMasuk->nama); ?>

        </td>
    </tr>
    <tr><td>pilihan 1</td>
        <td>
            <?php
                $pilihan1 = DB::table('prodis')->where('id', $register->pilihan1)->first();
            ?>
            <?php echo e($pilihan1->nama); ?>

        </td>
    </tr>
    <tr><td>pilihan 2</td>
        <td>
            <?php
                $pilihan2 = DB::table('prodis')->where('id', $register->pilihan2)->first();
            ?>
            <?php echo e($pilihan2->nama); ?>

        </td>
    </tr>
    <tr><td>pilihan 3</td>
        <td>
            <?php
                $pilihan3 = DB::table('prodis')->where('id', $register->pilihan3)->first();
            ?>
            <?php echo e($pilihan3->nama); ?>

        </td>
    </tr>
    <tr><td>Status Pembayaran</td>
        <td>
            <?php if($register->pembayaran === "belum"): ?>
                <p class="text-danger"><b>belum</b></p>
            <?php else: ?>
                <p class="text-success"><b>sudah</b></p>
            <?php endif; ?>
        </td>
    </tr>
    <tr><td>Status Penerimaan</td>
        <td>
            <?php if($register->status_diterima === "diterima"): ?>
                <p class="text-success"><b><?php echo e($register->status_diterima); ?></b></p>
            <?php else: ?>
                <p class="text-danger"><b><?php echo e($register->status_diterima); ?></b></p>
            <?php endif; ?>
        </td>
    </tr>
    <tr><td>Bukti Pembayaran</td>
        <td>
            <img style="max-width: 100%;" src="<?php echo e(asset('storage/'.$register->bukti_pembayaran)); ?>" alt="<?php echo e($register->nama); ?>">
        </td>
    </tr>
</tr>
<tr>
    <td>Pas Foto 3*4
    </td>
    <td>
        <?php if(isset($berkas->pas_foto_file) && $berkas->pas_foto_file !== null): ?>
            <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->pas_foto_file)); ?>" download="<?php echo e($berkas->pas_foto); ?>"><?php echo e($berkas->pas_foto); ?></a>
        <?php else: ?>
        <i class="text-secondary">belum upload</i>
        <?php endif; ?>        
    </td>
</tr>
<tr>
    <td>ijazah/skl
    </td>
    <td>
        <?php if(isset($berkas->ijazah_skl_file) && $berkas->ijazah_skl_file !== null): ?>
            <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->ijazah_skl_file)); ?>" download="<?php echo e($berkas->ijazah_skl); ?>"><?php echo e($berkas->ijazah_skl); ?></a>
        <?php else: ?>
        <i class="text-secondary">belum upload</i>
        <?php endif; ?>        
    </td>
</tr>
<tr>
    <td>SKHUN
    </td>
    <td>
        <?php if(isset($berkas->skhun_file) && $berkas->skhun_file !== null): ?>
            <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->skhun_file)); ?>" download="<?php echo e($berkas->skhun); ?>"><?php echo e($berkas->skhun); ?></a>
        <?php else: ?>
        <i class="text-secondary">belum upload</i>
        <?php endif; ?>        
    </td>
</tr>
<tr>
    <td>KK 
    </td>
    <td>
        <?php if(isset($berkas->kk_file) && $berkas->kk_file !== null): ?>
            <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->kk_file)); ?>" download="<?php echo e($berkas->kk); ?>"><?php echo e($berkas->kk); ?></a>
        <?php else: ?>
        <i class="text-secondary">belum upload</i>
        <?php endif; ?>        
    </td>
</tr>
<tr>
    <td>KTP 
    </td>
    <td>
        <?php if(isset($berkas->ktp_file) && $berkas->ktp_file !== null): ?>
            <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->ktp_file)); ?>" download="<?php echo e($berkas->ktp); ?>"><?php echo e($berkas->ktp); ?></a>
        <?php else: ?>
        <i class="text-secondary">belum upload</i>
        <?php endif; ?>        
    </td>
</tr>
<tr>
    <td>Akta Kelahiran 
    </td>
    <td>
        <?php if(isset($berkas->akta_file) && $berkas->akta_file !== null): ?>
            <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->akta_file)); ?>" download="<?php echo e($berkas->akta); ?>"><?php echo e($berkas->akta); ?></a>
        <?php else: ?>
        <i class="text-secondary">belum upload</i>
        <?php endif; ?>        
    </td>
</tr>
<tr>
    <td>Periode Pendaftaran 
    </td>
    <td>
        <?php echo e($register->created_at->format('Y')); ?>

    </td>
</tr>
</table>
<a href="<?php echo e(route('register.index')); ?>" class="btn btn-primary ms-4">back</a>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('superadmin')): ?>    
    <a href="<?php echo e(route('register.edit', $register->email)); ?>" class="btn btn-warning ms-2">edit</a>
<?php endif; ?>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\pmb-stkip\resources\views/dashboard/pendaftar/show.blade.php ENDPATH**/ ?>