
<?php $__env->startSection('container'); ?>

<div class="container text-center my-4">
  <div class="row">
    <div class="col">
        <?php if(isset($berkas->pas_foto) && $berkas->pas_foto !== null): ?>
          <img src="<?php echo e(asset('storage/'.$berkas->pas_foto_file)); ?>" alt="foto profil" class="rounded-circle img-thumbnail" style="width: 180px; height: 180px;">  
        <?php else: ?>
          <img src="<?php echo e(asset('assets/images/temporary-profile.jpg')); ?>" alt="foto profil" class="rounded-circle img-thumbnail" style="width: 180px; height: 180px;">            
        <?php endif; ?>
        <br>
        <table class="table text-start mt-3">
          <tr>
            <td>Nama</td>
            <td>:</td>
            <td><?php echo e($user->name); ?></td>
          </tr>
          <tr>
            <td>Email</td>
            <td>:</td>
            <td><?php echo e($user->email); ?></td>
          </tr>
          <tr>
            <td>Pilihan Prodi</td>
            <td>:</td>
            <td>
              pilihan 1: <?php echo e($user->register->pilihan1Prodi->nama); ?> <br>
              pilihan 2: <?php echo e($user->register->pilihan2Prodi->nama); ?> <br>
              pilihan 3: <?php echo e($user->register->pilihan3Prodi->nama); ?>

            </td>
          </tr>
        </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/dashboard/berkas_pendaftar/index.blade.php ENDPATH**/ ?>