
<?php $__env->startSection('container'); ?>

<div class="container text-center my-4">
    <div class="row d-flex justify-content-center align-items-center">
        <div class="col">
            <table class="table" style="border-collapse: separate; border-spacing: 10px">
                <form action="/simpan-pemberkasan" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <tr>
                        <td colspan="3">
                            <?php if(isset($berkas->pas_foto_file) && $berkas->pas_foto_file !== null): ?>
                                <img src="<?php echo e(asset('storage/'.$berkas->pas_foto_file)); ?>" alt="foto profil" class="rounded-circle img-thumbnail" style="width: 180px; height: 180px;">  
                                <br><?php echo e($user->name); ?>

                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/temporary-profile.jpg')); ?>" alt="foto profil" class="rounded-circle img-thumbnail" style="width: 180px; height: 180px;">            
                                <br><?php echo e($user->name); ?>

                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success mt-3">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Pas Foto 3*4
                            <br>
                            <?php if(isset($berkas->pas_foto_file) && $berkas->pas_foto_file !== null): ?>
                                <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->pas_foto_file)); ?>" download="<?php echo e($berkas->pas_foto); ?>"><?php echo e($berkas->pas_foto); ?></a>
                            <?php endif; ?>
                        </td>
                        <td>:</td>
                        <td><input type="file" name="pas_foto" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>ijazah/skl
                            <br>
                            <?php if(isset($berkas->ijazah_skl_file) && $berkas->ijazah_skl_file !== null): ?>
                                <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->ijazah_skl_file)); ?>" download="<?php echo e($berkas->ijazah_skl); ?>"><?php echo e($berkas->ijazah_skl); ?></a>
                            <?php endif; ?>
                        </td>
                        <td>:</td>
                        <td><input type="file" name="ijazah_skl" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>SKHUN
                            <br>
                            <?php if(isset($berkas->skhun_file) && $berkas->skhun_file !== null): ?>
                                <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->skhun_file)); ?>" download="<?php echo e($berkas->skhun); ?>"><?php echo e($berkas->skhun); ?></a>
                            <?php endif; ?>
                        </td>
                        <td>:</td>
                        <td><input type="file" name="skhun" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>KK 
                            <br>
                            <?php if(isset($berkas->kk_file) && $berkas->kk_file !== null): ?>
                                <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->kk_file)); ?>" download="<?php echo e($berkas->kk); ?>"><?php echo e($berkas->kk); ?></a>
                            <?php endif; ?>
                        </td>
                        <td>:</td>
                        <td><input type="file" name="kk" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>KTP 
                            <br>
                            <?php if(isset($berkas->ktp_file) && $berkas->ktp_file !== null): ?>
                                <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->ktp_file)); ?>" download="<?php echo e($berkas->ktp); ?>"><?php echo e($berkas->ktp); ?></a>
                            <?php endif; ?>
                        </td>
                        <td>:</td>
                        <td><input type="file" name="ktp" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Akta Kelahiran 
                            <br>
                            <?php if(isset($berkas->akta_file) && $berkas->akta_file !== null): ?>
                                <a style="color: blue; text-decoration: none" href="<?php echo e(asset('storage/'.$berkas->akta_file)); ?>" download="<?php echo e($berkas->akta); ?>"><?php echo e($berkas->akta); ?></a>
                            <?php endif; ?>
                        </td>
                        <td>:</td>
                        <td><input type="file" name="akta" class="form-control"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="text-start">
                            <i class="text-danger">*Jika sudah mengisi dan ada preview file yang bisa di download, MOHON untuk TIDAK di upload ulang KECUALI salah file.</i> <br><br>
                            <a href="/pemberkasan" class="btn btn-primary">Refresh</a>
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </td>
                    </tr>
                </form>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\pmb-stkip\resources\views/dashboard/berkas_pendaftar/pemberkasan.blade.php ENDPATH**/ ?>