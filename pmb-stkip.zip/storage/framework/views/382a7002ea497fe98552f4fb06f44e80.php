<?php $__env->startSection('container'); ?>


<center><h3 class="m-3 mt-5">
    Semua Pengumuman
</h3></center>
<div class="container mb-5">
    <div class="row">
        <?php $__currentLoopData = $informasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">
                <div class="card m-2 p-4">
                    <?php if($informasi->image !== null): ?>
                        <img class="img-fluid w-100 h-80" src="<?php echo e(asset('storage/'.$informasi->image)); ?>" class="card-img-top" alt="<?php echo e($informasi->title); ?>">
                    <?php else: ?>
                        <img class="img-fluid w-100 h-80" src="https://picsum.photos/200/150?grayscale&random&keyword=<?php echo e($informasi->title); ?>" class="card-img-top" alt="<?php echo e($informasi->title); ?>">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($informasi->title); ?></h5>
                        <p class="card-text"><?php echo Str::limit($informasi->content,50); ?></p>
                        <a href="/pengumuman/<?php echo e($informasi->slug); ?>" class="btn btn-primary">Lihat</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row">
        <div class="col">
            <div class="d-flex justify-content-end">
                <?php echo e($informasis->links()); ?>

            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/dashboard/pengumuman/show_all.blade.php ENDPATH**/ ?>