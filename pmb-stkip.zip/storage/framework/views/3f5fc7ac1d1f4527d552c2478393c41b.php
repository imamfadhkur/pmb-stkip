<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>
<body class="bg-dark">
    <div class="container my-5 py-4">
        <div class="row d-flex justify-content-center align-items-center">
            <div class="col col-md-6 col-lg-4 bg-light rounded">
                <main class="form-signin p-4">
                    <h1 class="h3 mb-3 fw-normal text-center">STKIPPGRI-BKL ADMINISTRATOR</h1>
                    <form action="/8080:2024" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group mt-4">
                            Username/Email
                            <input type="text" class="form-control my-2 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                is-invalid
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="email" required value="<?php echo e(old('email')); ?>">
                        </div>
                        <div class="form-group mt-4">
                            Password
                            <input type="password" class="form-control my-2" id="password" name="password" required>
                            <input type="checkbox" onclick="showPassword()" class="mb-4"> Show Password
                        </div>
                        <input type="hidden" value="admin" name="role">
                        <button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>
                        <center class="mt-2"><a href="<?php echo e(url('/')); ?>" class="text-decoration-none">/home</a></center>
                    </form>
                </main>
            </div>
        </div>
    </div>

    <script>
        function showPassword() {
        var x = document.getElementById("password");
        var y = document.getElementById("password_confirmation");
        var z = document.getElementById("current_password");
        if (x.type === "password") {
          x.type = "text";
          y.type = "text";
          z.type = "text";
        } else {
          x.type = "password";
          y.type = "password";
          z.type = "password";
        }
      }
    </script>
</body>
</html><?php /**PATH D:\app\pmb-stkip\resources\views/auth/login_administrator.blade.php ENDPATH**/ ?>