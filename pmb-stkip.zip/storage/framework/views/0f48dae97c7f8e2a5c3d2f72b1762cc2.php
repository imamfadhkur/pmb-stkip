<?php $__env->startSection('container'); ?>

<div class="wrapper d-flex align-items-stretch">
  <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="content" class="p-md-3">
    <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <?php if(session('messageSuccess')): ?>
        <div class="alert alert-success">
            <?php echo e(session('messageSuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if($daftarUlang === null): ?>
        <p>Buat informasi pendaftaran ulang untuk calon mahasiswa baru.</p>
        <a href="/admin-pengumuman/create" class="btn btn-primary mb-2"><i class="bi bi-plus-square"></i> Buat informasi</a>
    <?php endif; ?>
    <?php if($daftarUlang !== null): ?>
        <?php echo e($daftarUlang->content); ?>

        <a href="/admin-pengumuman/<?php echo e($daftarUlang->id); ?>/edit" class="btn btn-warning mb-2"><i class="bi bi-pencil-square"></i> Edit data</a>
    <?php endif; ?>
    

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/dashboard/daftar_ulang/index.blade.php ENDPATH**/ ?>