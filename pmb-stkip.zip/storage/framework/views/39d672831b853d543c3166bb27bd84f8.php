<!-- Footer -->
<footer class="bg-my-gray-dark py-4 px-5 mt-2">
  <div class="container">
    <div class="row justify-content-center">
        <div class="col text-md-center">
            <?php if($informasiKampus->alamat !== null): ?> 
                <div class="mt-2">
                    <div class="d-inline"><img class="img" style="max-height: 15px" src="<?php echo e(asset('assets/images/logo-stkipbkl.png')); ?>" alt=""></div>
                    <div class="d-inline mt-1 ms-1"><?php echo e($informasiKampus->name); ?></div>
                </div>
                <div class="mt-2">
                    <div class="d-inline"><i class="bi bi-geo-alt"></i></div>
                    <div class="d-inline ms-1"><?php echo e($informasiKampus->alamat); ?></div>
                </div>
            <?php endif; ?>
            <?php if($informasiKampus->email !== null): ?>    
                <div class="mt-2">
                    <div class="d-inline"><i class="bi bi-envelope"></i></div>
                    <div class="d-inline ms-1"><?php echo e($informasiKampus->email); ?></div>
                </div>
            <?php endif; ?>
            <?php if($informasiKampus->noTelp !== null): ?>
                <div class="mt-2">
                    <div class="d-inline"><i class="bi bi-telephone"></i></div>
                    <div class="d-inline ms-1"><?php echo e($informasiKampus->noTelp); ?></div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row justify-content-center mt-4">
        <div class="col text-md-center">
            <?php $__currentLoopData = $footerSosmed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sosmed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url($sosmed->link)); ?>" class="text-decoration-none m-1 text-light" target="_blank"><?php echo $sosmed->icon; ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="row justify-content-center mt-4">
        <div class="col text-md-center">
            <?php if(auth()->guard()->check()): ?>
            <?php else: ?>
                <a class="text-light" href="<?php echo e(url('8080:2024')); ?>">admin login</a>
            <?php endif; ?>
        </div>
    </div>
</div>

  </footer><?php /**PATH D:\app\pmb-stkip\resources\views/partials/footer.blade.php ENDPATH**/ ?>