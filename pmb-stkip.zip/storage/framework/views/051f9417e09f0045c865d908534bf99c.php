<?php $__env->startSection('container'); ?>

<div class="wrapper d-flex align-items-stretch">
  <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="content" class="p-md-3">
    <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <?php if(session('messageSuccess')): ?>
        <div class="alert alert-success">
            <?php echo e(session('messageSuccess')); ?>

        </div>
    <?php endif; ?>   
    <?php if(session('messageFailed')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('messageFailed')); ?>

        </div>
    <?php endif; ?>
    <a href="/admin-pengumuman/create" class="btn btn-primary mb-2"><i class="bi bi-plus-square"></i> Buat pengumuman</a>
    <table class="table table-hover">
        <tr>
            <th>No.</th>
            <th>Judul</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $informasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?>.</td>
                <td><?php echo e($informasi->title); ?></td>
                <td>
                    <a class="btn btn-sm btn-primary m-1" title="lihat data" href="<?php echo e(route('admin-pengumuman.show', $informasi->slug)); ?>" style="display: inline-block;"><i class="bi bi-eye"></i></a>
                    <a class="btn btn-sm btn-warning m-1" title="edit" href="/admin-pengumuman/<?php echo e($informasi->slug); ?>/edit" style="display: inline-block;"><i class="bi bi-pencil"></i></a>
                    <form action="<?php echo e(route('admin-pengumuman.destroy', $informasi->slug)); ?>" method="POST" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger m-1" onclick="return confirm('Apakah anda yakin ingin menghapus?')"><i class="bi bi-trash"></i></button>
                    </form>                      
                </td>                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="d-flex justify-content-end">
        <?php echo e($informasis->links()); ?>

    </div>
    

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\pmb-stkip\resources\views/dashboard/pengumuman/index.blade.php ENDPATH**/ ?>