<?php $__env->startSection('container'); ?>

<div class="container my-5 p-5">
  <div class="row">
    <div class="col">
      <h2 class="m-3 text-center"><a class="text-decoration-none" href="/info-prodi">Semua Prodi</a></h2>
    </div>
  </div>
    <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <div class="row">
            <div class="col">
                <div class="card text-center m-3">
                    <div class="card-header">
                      <h5><?php echo e($prodi->nama); ?></h5>
                    </div>
                    <div class="card-body">
                      
                        <?php
                            $deskripsi = strip_tags($prodi->deskripsi); // menghapus tag HTML dari deskripsi
                            $desk = Str::limit($deskripsi, rand(160, 200)); // membatasi jumlah karakter secara random
                        ?>
                        <p class="card-text"><?php echo $desk; ?></p>
                      <a href="/info-prodi/<?php echo e($prodi->id); ?>" class="">Selengkapnya</a>
                    </div>
                    <div class="card-footer text-body-secondary">
                        <?php if($prodi->updated_at): ?>
                            <?php echo e($prodi->updated_at->format('d F Y H:i:s')); ?>

                        <?php endif; ?>
                    </div>                  
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="d-flex justify-content-end">
            <?php echo e($prodis->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\pmb-stkip\resources\views/umum/prodi/index.blade.php ENDPATH**/ ?>