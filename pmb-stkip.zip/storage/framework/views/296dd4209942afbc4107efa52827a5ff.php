
<?php $__env->startSection('container'); ?>

<div class="container my-5 p-5"> 
    <div class="row">
        <div class="col">
            <h4 class="m-3"><a href="/" class="text-decoration-none text-dark"><i class="bi bi-house-door"></i>:</a> <a href="/info-jalur-seleksi">Jalur Seleksi</a> / <a href="/info-jalur-seleksi/<?php echo e($jalur_masuk->id); ?>" class=""><?php echo e($jalur_masuk->nama); ?></a></h4>
            <div class="card m-3">
                <div class="card-body">
                    <div class="mb-4">
                        <h3 class="card-title"><?php echo e($jalur_masuk->nama); ?></h3>
                        <i class="text-secondary">Di update pada: <?php echo e($jalur_masuk->updated_at->format('d F Y H:i:s')); ?></i>
                    </div>
                    <div>
                        <p>biaya: <?php echo e($jalur_masuk->biaya); ?></p>
                        <p>jumlah pendaftar: <?php echo e($jalur_masuk->jumlah_pendaftar); ?></p>
                        <p>jumlah maks pendaftar: <?php echo e($jalur_masuk->jumlah_maks_pendaftar); ?></p>
                        <p>status: <?php echo e($jalur_masuk->status); ?></p>
                        <p class="card-text mt-3"><?php echo $jalur_masuk->deskripsi; ?></p>
                        <i><a href="/info-jalur-seleksi">Kembali...</a></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/umum/jalur_masuk/show.blade.php ENDPATH**/ ?>