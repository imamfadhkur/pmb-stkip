<?php $__env->startSection('container'); ?>

<div class="wrapper d-flex align-items-stretch">
  <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="content" class="p-md-3">
    <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <div class="container">
        <div class="row">
            <div class="col-10">
                <form action="/admin-pengumuman" method="POST">
                    <?php echo csrf_field(); ?>
                    <label class="mt-4" for="content">Isi Pengumumam:</label>
                    <textarea name="content" id="editor1" required></textarea>
                    <input type="hidden" name="jenis" value="daftar-ulang">
                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                </form>
            </div>
        </div>
    </div>
    

    </div>
</div>

<script>
    CKEDITOR.replace( 'editor1' );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/dashboard/daftar_ulang/create.blade.php ENDPATH**/ ?>