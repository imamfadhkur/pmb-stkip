
<?php $__env->startSection('container'); ?>

<div class="container my-5 p-5"> 
    <div class="row">
        <div class="col">
            <h4 class="m-3"><a href="/" class="text-decoration-none text-dark"><i class="bi bi-house-door"></i>:</a> <a href="/info-prodi">Prodi</a> / <a href="/info-prodi/<?php echo e($prodi->id); ?>" class=""><?php echo e($prodi->nama); ?></a></h4>
            <div class="card m-3">
                <div class="card-body">
                    <div class="mb-3">
                        <h3 class="card-title"><?php echo e($prodi->nama); ?></h3>
                        <i class="text-secondary">Di update pada: <?php echo e($prodi->updated_at->format('d F Y H:i:s')); ?></i>
                    </div>
                    <div>
                        <p class="card-text mt-3"><?php echo $prodi->deskripsi; ?></p>
                        <i><a href="/info-prodi">Kembali...</a></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/umum/prodi/show.blade.php ENDPATH**/ ?>