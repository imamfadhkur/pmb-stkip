<?php $__env->startSection('container'); ?>

<div class="wrapper d-flex align-items-stretch">
  <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="content" class="p-md-3">
    <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <div class="container">
        <div class="row">
            <div class="col-10">
                <?php if(session('messageFailed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('messageFailed')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('admin-pengumuman.update', $informasi->slug)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title">Judul:</label>
                        <input type="text" name="title" id="title" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('title', $informasi->title)); ?>">
                        <?php if($errors->has('title')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('title')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label class="mt-4" for="image">Gambar:</label>
                        <?php if($informasi->image): ?>
                            <img class="m-2" src="<?php echo e(asset('storage/'.$informasi->image)); ?>" alt="pengumuman" style="max-width: 100px;">
                        <?php endif; ?>
                        <input type="file" name="image" id="image" class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>">
                        <?php if($errors->has('image')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('image')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label class="mt-4" for="content">Isi Pengumumam:</label>
                        <textarea class="<?php echo e($errors->has('content') ? ' is-invalid' : ''); ?>" name="content" id="editor1" required><?php echo e(old('content', $informasi->content)); ?></textarea>
                        <?php if($errors->has('content')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('content')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <a href="/admin-pengumuman" class="btn btn-danger">cancel</a>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
    

    </div>
</div>

<script>
    CKEDITOR.replace( 'editor1' );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/dashboard/pengumuman/edit.blade.php ENDPATH**/ ?>