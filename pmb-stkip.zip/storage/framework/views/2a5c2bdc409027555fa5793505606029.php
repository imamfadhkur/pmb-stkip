<?php $__env->startSection('container'); ?>

    
    <div class="container">
        <div class="row m-4">
            <div class="col-10 mt-4">
                <h3><?php echo e($informasi->title); ?></h3>
                <?php if($informasi->image !== null): ?>
                    <img class="img-fluid w-70" src="<?php echo e(asset('storage/'.$informasi->image)); ?>" alt="pengumuman">
                <?php endif; ?>
                <p><?php echo $informasi->content; ?></p>
                <br>
                <a href="/pengumuman/index" class="btn btn-primary">kembali</a>
            </div>
        </div>
    </div>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/dashboard/pengumuman/show_satu.blade.php ENDPATH**/ ?>