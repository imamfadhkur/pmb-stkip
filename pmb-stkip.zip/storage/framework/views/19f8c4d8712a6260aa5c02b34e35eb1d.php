<?php $__env->startSection('container'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col">
            <h3 class="mx-4 mt-2">Jalur Pendaftaran</h3>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <form action="data-diri" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group m-4">
                  <label for="jenjang_pendidikan">Jenjang Pendidikan</label>
                  <select class="form-control" id="jenjang_pendidikan" name="jenjang_pendidikan">
                    <?php $__currentLoopData = $jenjang_pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($jp->id); ?>"><?php echo e($jp->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              
                <div class="form-group m-4">
                  <label for="sistem_kuliah">Sistem Kuliah</label>
                  <select class="form-control" id="sistem_kuliah" name="sistem_kuliah">
                    <?php $__currentLoopData = $sistem_kuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sk->id); ?>"><?php echo e($sk->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              
                <div class="form-group m-4">
                  <label for="jalur_masuk">Jalur Masuk</label>
                  <select class="form-control" id="jalur_masuk" name="jalur_masuk">
                    <?php $__currentLoopData = $jalur_masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($jm->id); ?>"><?php echo e($jm->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              
                <button type="submit" class="btn btn-primary mx-4">Selanjutnya</button>
              </form>              
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/form_jalur_pendaftaran.blade.php ENDPATH**/ ?>