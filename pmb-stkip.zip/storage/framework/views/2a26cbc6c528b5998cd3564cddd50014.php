<?php $__env->startSection('container'); ?>

<div class="wrapper d-flex align-items-stretch">
  <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="content" class="p-md-3">
    <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <div class="container">
        <div class="row">
            <div class="col-6">
                <form action="/settings/update-data-bank/<?php echo e($id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <label class="mt-4" for="nama_bank">Nama Bank:</label>
                    <input type="text" name="nama_bank" class="form-control" value="<?php echo e($nama_bank); ?>" required>
                    <label class="mt-4" for="nomor_rekening">Nomor Rekening:</label>
                    <input type="number" name="nomor_rekening" class="form-control" value="<?php echo e($nomor_rekening); ?>" required>
                    <label class="mt-4" for="nama_pemilik">Nama Pemilik:</label>
                    <input type="text" name="nama_pemilik" class="form-control" value="<?php echo e($nama_pemilik); ?>" required>
                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                </form>
            </div>
        </div>
    </div>
    

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\pmb-stkip\resources\views/dashboard/bank/edit.blade.php ENDPATH**/ ?>