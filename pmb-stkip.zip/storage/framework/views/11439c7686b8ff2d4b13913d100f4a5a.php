<?php $__env->startSection('container'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col">
            <h4 class="mx-4 mt-3">Edit Data Anda:</h4>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <form action="daftar" method="POST">
                <?php echo csrf_field(); ?>

                <table class="table mx-4">
                    <tr>
                        <td>Jenjang Pendidikan</td>
                        <td>
                            <select class="form-control" id="jenjang_pendidikan" name="jenjang_pendidikan">
                                <?php $__currentLoopData = DB::table('jenjang_pendidikans')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($jp->id); ?>" <?php echo e(($jenjang_pendidikan == $jp->id) ? 'selected' : ''); ?>><?php echo e($jp->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr><td>sistem kuliah</td>
                        <td>
                            <select class="form-control" id="sistem_kuliah" name="sistem_kuliah">
                                <?php $__currentLoopData = DB::table('sistem_kuliahs')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sk->id); ?>" <?php echo e(($sistem_kuliah == $sk->id) ? 'selected' : ''); ?>><?php echo e($sk->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr><td>jalur masuk</td>
                        <td>
                            <select class="form-control" id="jalur_masuk" name="jalur_masuk">
                                <?php $__currentLoopData = DB::table('jalur_masuks')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($jm->id); ?>" <?php echo e(($jalur_masuk == $jm->id) ? 'selected' : ''); ?>><?php echo e($jm->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr><td>nama</td>
                        <td><input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $nama)); ?>">
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>jenis kelamin</td>
                        <td><select name="jk" class="form-control">
                            <option value="L" <?php echo e(old('jk', $jk) == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                            <option value="P" <?php echo e(old('jk', $jk) == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                          </select>
                          <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </td>
                    </tr>
                    <tr><td>hp</td>
                        <td><input type="number" name="hp" class="form-control" value="<?php echo e(old('hp', $hp)); ?>">
                            <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>email</td>
                        <td><input type="email" name="email" class="form-control" value="<?php echo e(old('email', $email)); ?>"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>tempat, tanggal lahir</td>
                        <td>
                            <input type="text" name="tempat_lahir" value="<?php echo e(old('tempat_lahir', $tempat_lahir)); ?>" required>
                            <input type="date" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir', $tanggal_lahir)); ?>" required>
                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>alamat</td>
                        <td><input type="text" name="alamat" class="form-control" value="<?php echo e(old('alamat', $alamat)); ?>">
                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>kewarganegaraan</td>
                        <td><input type="text" name="kewarganegaraan" class="form-control" value="<?php echo e(old('kewarganegaraan', $kewarganegaraan)); ?>">
                            <?php $__errorArgs = ['kewarganegaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>identitas kewarganegaraan</td>
                        <td><input type="number" name="identitas_kewarganegaraan" class="form-control" value="<?php echo e(old('identitas_kewarganegaraan', $identitas_kewarganegaraan)); ?>"><?php $__errorArgs = ['identitas_kewarganegaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr><td>nama sekolah asal</td>
                        <td><input type="text" name="nama_sekolah" class="form-control" value="<?php echo e(old('nama_sekolah',$nama_sekolah)); ?>">
                            <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>jenis sekolah</td>
                        <td><input type="text" name="jenis_sekolah" class="form-control" placeholder="SMA/SMK/MA/Lainnya" value="<?php echo e(old('jenis_sekolah',$jenis_sekolah)); ?>">
                            <?php $__errorArgs = ['jenis_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>jurusan sekolah</td>
                        <td><input type="text" name="jurusan_sekolah" placeholder="IPA/IPS/Lainnya" class="form-control" value="<?php echo e(old('jurusan_sekolah',$jurusan_sekolah)); ?>">
                            <?php $__errorArgs = ['jurusan_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>tahun lulus</td>
                        <td><input type="number" name="tahun_lulus" class="form-control" value="<?php echo e(old('tahun_lulus',$tahun_lulus)); ?>">
                            <?php $__errorArgs = ['tahun_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>alamat sekolah</td>
                        <td><input type="text" name="alamat_sekolah" class="form-control" value="<?php echo e(old('alamat_sekolah',$alamat_sekolah)); ?>">
                            <?php $__errorArgs = ['alamat_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                    </tr>
                    <tr><td>pilihan 1</td>
                        <td>
                            <select class="form-control" id="pilihan1" name="pilihan1">
                                <?php $__currentLoopData = DB::table('prodis')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pilihan->id); ?>" <?php echo e(($pilihan1 == $pilihan->id) ? 'selected' : ''); ?>><?php echo e($pilihan->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                <?php $__errorArgs = ['pilihan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr><td>pilihan 2</td>
                        <td>
                            <select class="form-control" id="pilihan2" name="pilihan2">
                                <?php $__currentLoopData = DB::table('prodis')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pilihan->id); ?>" <?php echo e(($pilihan2 == $pilihan->id) ? 'selected' : ''); ?>><?php echo e($pilihan->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                <?php $__errorArgs = ['pilihan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr><td>pilihan 3</td>
                        <td>
                            <select class="form-control" id="pilihan3" name="pilihan3">
                                <?php $__currentLoopData = DB::table('prodis')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pilihan->id); ?>" <?php echo e(($pilihan3 == $pilihan->id) ? 'selected' : ''); ?>><?php echo e($pilihan->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                <?php $__errorArgs = ['pilihan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><i class="text-danger">3 pilihan tidak boleh sama.</i><br></td>
                    </tr>
                  </table>
                <button type="submit" class="btn btn-primary me-4" value="save" name="type">Daftar</button>
              </form>              
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\pmb-stkip\resources\views/form_edit_konfirmasi.blade.php ENDPATH**/ ?>