<?php $__env->startSection('container'); ?>

<div class="wrapper d-flex align-items-stretch">
  <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="content" class="p-md-3">
    <?php echo $__env->make('dashboard.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <?php if(session('messageSuccess')): ?>
        <div class="alert alert-success">
            <?php echo e(session('messageSuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('messageError')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('messageError')); ?>

        </div>
    <?php endif; ?>
    <a href="/settings/create_sosmed" class="btn btn-primary mb-2"><i class="bi bi-plus-square"></i> Tambah sosmed</a>
    <table class="table table-hover">
        <tr>
            <th></th>
            <th>Nama</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?>.</td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td style="display: flex; gap: 10px;">
                    <form action="/settings/edit-user" method="POST"> <?php echo csrf_field(); ?> <input type="hidden" value="<?php echo e($user->id); ?>" name="id"><button type="submit" title="edit <?php echo e($user->nama_platform); ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i></button></form>
                    <form action="/settings/delete-user" method="POST"> <?php echo csrf_field(); ?> <input type="hidden" value="<?php echo e($user->id); ?>" name="id"><button type="submit" title="hapus <?php echo e($user->nama_platform); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')"><i class="bi bi-trash"></i></button></form>
                </td>                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\app\pmb-stkip\resources\views/dashboard/admin/index.blade.php ENDPATH**/ ?>