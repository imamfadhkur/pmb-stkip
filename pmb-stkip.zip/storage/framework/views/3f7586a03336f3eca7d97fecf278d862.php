<?php $__env->startSection('container'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col">
            <h4 class="mx-4 mt-3">Konfirmasi Data Anda:</h4>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <form action="daftar" method="POST">
                <?php echo csrf_field(); ?>
                
                
                <input type="hidden" value="<?php echo e($jenjang_pendidikan); ?>" name="jenjang_pendidikan">
                <input type="hidden" value="<?php echo e($sistem_kuliah); ?>" name="sistem_kuliah">
                <input type="hidden" value="<?php echo e($jalur_masuk); ?>" name="jalur_masuk">
                <input type="hidden" value="<?php echo e($nama); ?>" name="nama">
                <input type="hidden" value="<?php echo e($jk); ?>" name="jk">
                <input type="hidden" value="<?php echo e($hp); ?>" name="hp">
                <input type="hidden" value="<?php echo e($email); ?>" name="email">
                <input type="hidden" value="<?php echo e($tempat_lahir); ?>" name="tempat_lahir">
                <input type="hidden" value="<?php echo e($tanggal_lahir); ?>" name="tanggal_lahir">
                <input type="hidden" value="<?php echo e($alamat); ?>" name="alamat">
                <input type="hidden" value="<?php echo e($kewarganegaraan); ?>" name="kewarganegaraan">
                <input type="hidden" value="<?php echo e($identitas_kewarganegaraan); ?>" name="identitas_kewarganegaraan">
                <input type="hidden" value="<?php echo e($nama_sekolah); ?>" name="nama_sekolah">
                <input type="hidden" value="<?php echo e($jenis_sekolah); ?>" name="jenis_sekolah">
                <input type="hidden" value="<?php echo e($jurusan_sekolah); ?>" name="jurusan_sekolah">
                <input type="hidden" value="<?php echo e($tahun_lulus); ?>" name="tahun_lulus">
                <input type="hidden" value="<?php echo e($nisn); ?>" name="nisn">
                <input type="hidden" value="<?php echo e($nama_ibu); ?>" name="nama_ibu">
                <input type="hidden" value="<?php echo e($alamat_sekolah); ?>" name="alamat_sekolah">
                <input type="hidden" value="<?php echo e($pilihan1); ?>" name="pilihan1">
                <input type="hidden" value="<?php echo e($pilihan2); ?>" name="pilihan2">
                <input type="hidden" value="<?php echo e($pilihan3); ?>" name="pilihan3">

                <table class="table mx-4">
                    <tr>
                        <td>Jenjang Pendidikan</td>
                        <td>
                            <?php
                                $jenjangPendidikan = DB::table('jenjang_pendidikans')->where('id', $jenjang_pendidikan)->first();
                            ?>
                            <?php echo e($jenjangPendidikan->nama); ?>

                        </td>
                    </tr>
                    <tr><td>sistem kuliah</td>
                        <td>
                            <?php
                                $sistemKuliah = DB::table('sistem_kuliahs')->where('id', $sistem_kuliah)->first();
                            ?>
                            <?php echo e($sistemKuliah->nama); ?>

                        </td>
                    </tr>
                    <tr><td>jalur masuk</td>
                        <td>
                            <?php
                                $jalurMasuk = DB::table('jalur_masuks')->where('id', $jalur_masuk)->first();
                            ?>
                            <?php echo e($jalurMasuk->nama); ?>

                        </td>
                    </tr>
                    <tr><td>nama</td>
                        <td><?php echo e($nama); ?></td>
                    </tr>
                    <tr><td>jenis kelamin</td>
                        <td><?php echo e($jk); ?></td>
                    </tr>
                    <tr><td>hp</td>
                        <td><?php echo e($hp); ?></td>
                    </tr>
                    <tr><td>email</td>
                        <td><?php echo e($email); ?></td>
                    </tr>
                    <tr><td>tempat, tanggal lahir</td>
                        <td><?php echo e($tempat_lahir); ?>, <?php echo e(\Carbon\Carbon::parse($tanggal_lahir)->format('d-m-Y')); ?></td>
                    </tr>
                    <tr><td>alamat</td>
                        <td><?php echo e($alamat); ?></td>
                    </tr>
                    <tr><td>kewarganegaraan</td>
                        <td><?php echo e($kewarganegaraan); ?></td>
                    </tr>
                    <tr><td>identitas kewarganegaraan</td>
                        <td><?php echo e($identitas_kewarganegaraan); ?></td>
                    </tr>
                    <tr><td>nama ibu</td>
                        <td><?php echo e($nama_ibu); ?></td>
                    </tr>
                    <tr><td>nama sekolah asal</td>
                        <td><?php echo e($nama_sekolah); ?></td>
                    </tr>
                    <tr><td>jenis sekolah</td>
                        <td><?php echo e($jenis_sekolah); ?></td>
                    </tr>
                    <tr><td>jurusan sekolah</td>
                        <td><?php echo e($jurusan_sekolah); ?></td>
                    </tr>
                    <tr><td>tahun lulus</td>
                        <td><?php echo e($tahun_lulus); ?></td>
                    </tr>
                    <tr><td>nisn</td>
                        <td><?php echo e($nisn); ?></td>
                    </tr>
                    <tr><td>alamat sekolah</td>
                        <td><?php echo e($alamat_sekolah); ?></td>
                    </tr>
                    <tr><td>pilihan 1</td>
                        <td>
                            <?php
                                $pilihan1 = DB::table('prodis')->where('id', $pilihan1)->first();
                            ?>
                            <?php echo e($pilihan1->nama); ?>

                        </td>
                    </tr>
                    <tr><td>pilihan 2</td>
                        <td>
                            <?php
                                $pilihan2 = DB::table('prodis')->where('id', $pilihan2)->first();
                            ?>
                            <?php echo e($pilihan2->nama); ?>

                        </td>
                    </tr>
                    <tr><td>pilihan 3</td>
                        <td>
                            <?php
                                $pilihan3 = DB::table('prodis')->where('id', $pilihan3)->first();
                            ?>
                            <?php echo e($pilihan3->nama); ?>

                        </td>
                    </tr>
                </table>
              
                <button type="submit" class="btn btn-light ms-4" value="edit" name="type">Edit</button>
                <button type="submit" class="btn btn-primary me-4" value="save" name="type">Daftar</button>
              </form>              
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\pmb-stkip\resources\views/form_konfirmasi.blade.php ENDPATH**/ ?>